export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

function cleanAndNormalizeUrl(input: string): string {
  if (!input) return '';
  let str = input.trim();
  if (!str.startsWith('http://') && !str.startsWith('https://')) {
    if (str.startsWith('192.168.') || str.startsWith('10.') || str.startsWith('127.0.0.1') || str.startsWith('localhost')) {
      str = 'http://' + str;
    } else {
      str = 'https://' + str;
    }
  }
  str = str.replace(/\/+$/, '');
  try {
    const u = new URL(str);
    if (!u.port && (u.hostname.startsWith('192.168.') || u.hostname.startsWith('10.') || u.hostname === '127.0.0.1' || u.hostname === 'localhost')) {
      u.port = '11434';
      str = u.toString().replace(/\/+$/, '');
    }
  } catch (e) {}

  if (!str.endsWith('/api/generate')) {
    str = str.replace(/\/api\/chat\/?$/, '').replace(/\/api\/?$/, '');
    str = str + '/api/generate';
  }
  return str;
}

export async function GET(req: Request) {
  const isCloudEnv = !!(
    process.env.NETLIFY ||
    process.env.VERCEL ||
    process.env.AWS_LAMBDA_FUNCTION_NAME ||
    process.env.LAMBDA_TASK_ROOT ||
    (typeof process.cwd === 'function' && process.cwd().startsWith('/var/task'))
  );

  const cloudDefaultApiKey = 'lo_live_qDYoGoQFKz7bM35ijtVa-9BwznoFZhqO';

  let configuredEndpoint = '';
  let configuredApiKey = (process.env.LOCAL_AI_API_KEY || '').trim();

  // 1. Check if client passed an endpoint via query param or header (highest priority)
  try {
    const url = new URL(req.url);
    const paramEp = url.searchParams.get('endpoint') || req.headers.get('x-ai-endpoint');
    if (paramEp && paramEp.trim()) {
      configuredEndpoint = paramEp.trim();
    }
  } catch (e) {}

  // 2. Check if configured in UI Settings table in database
  if (!configuredEndpoint) {
    try {
      const settingRow = getDb().prepare("SELECT value FROM settings WHERE id = 'aiEndpoint'").get() as any;
      if (settingRow && settingRow.value) {
        const parsed = JSON.parse(settingRow.value);
        if (typeof parsed === 'string' && parsed.trim()) {
          configuredEndpoint = parsed.trim();
        }
      }
    } catch (e) {}
  }

  // 3. Fallback to process.env.LOCAL_AI_ENDPOINT if valid and not expired placeholder
  if (!configuredEndpoint && process.env.LOCAL_AI_ENDPOINT) {
    const envEp = process.env.LOCAL_AI_ENDPOINT.trim();
    if (!envEp.includes('entrepreneurs-psp-navigate-maternity') && !envEp.includes('your-tunnel-subdomain')) {
      configuredEndpoint = envEp;
    }
  }

  // 4. Check if local .tunnel-status.json exists (on-premise local dev/server)
  if (!configuredEndpoint) {
    try {
      const fs = require('fs');
      const path = require('path');
      const statusPath = path.resolve(process.cwd(), '.tunnel-status.json');
      if (fs.existsSync(statusPath)) {
        const statusData = JSON.parse(fs.readFileSync(statusPath, 'utf-8'));
        if (statusData && statusData.endpoint) {
          configuredEndpoint = statusData.endpoint;
        }
      }
    } catch (e) {}
  }

  // 5. Default fallback to active live Cloudflare tunnel or local LAN
  if (!configuredEndpoint) {
    configuredEndpoint = isCloudEnv
      ? 'https://publicly-suggest-percent-relevant.trycloudflare.com/api/generate'
      : 'http://192.168.0.80:11434/api/generate';
  }

  // 6. Filter out any obsolete or dead placeholders
  if (configuredEndpoint && (
    configuredEndpoint.includes('orientation-humanities-inc-leg') ||
    configuredEndpoint.includes('discussion-mile-campaign-statistics') ||
    configuredEndpoint.includes('entrepreneurs-psp-navigate-maternity') ||
    configuredEndpoint.includes('your-tunnel-subdomain') ||
    configuredEndpoint.includes('millions-librarian-consumer-desktops') ||
    configuredEndpoint.includes('garmin-emotions-insured-dual')
  )) {
    configuredEndpoint = isCloudEnv
      ? 'https://publicly-suggest-percent-relevant.trycloudflare.com/api/generate'
      : 'http://192.168.0.80:11434/api/generate';
  }

  // 7. Normalize configuredEndpoint if present
  if (configuredEndpoint) {
    configuredEndpoint = cleanAndNormalizeUrl(configuredEndpoint);
  }

  if (!configuredApiKey) {
    configuredApiKey = cloudDefaultApiKey;
  }

  const result: any = {
    database: { status: 'unknown' },
    aiServer: {
      endpoint: configuredEndpoint || '',
      model: process.env.LOCAL_AI_MODEL || 'llama3.1:latest',
      status: 'unknown'
    }
  };

  // 1. Check SQLite
  try {
    const db = getDb();
    const userCount = db.prepare('SELECT count(*) as count FROM users').get() as any;
    result.database = {
      status: 'connected',
      totalUsers: userCount?.count || 0
    };
  } catch (dbErr: any) {
    result.database = {
      status: 'error',
      error: dbErr?.message || String(dbErr)
    };
  }

  // Explicit validation against Cloudflare documentation URL
  if (configuredEndpoint && configuredEndpoint.includes('developers.cloudflare.com')) {
    result.aiServer.status = 'error';
    result.aiServer.error = "Invalid endpoint: 'developers.cloudflare.com' is Cloudflare's documentation link from the banner. In your Linux terminal, copy the assigned tunnel link shown directly below it: https://<subdomain>.trycloudflare.com";
    return NextResponse.json(result);
  }

  // Detect private LAN IPs when running on Netlify Cloud
  if (isCloudEnv && configuredEndpoint && (
    configuredEndpoint.includes('192.168.') ||
    configuredEndpoint.includes('10.') ||
    configuredEndpoint.includes('127.0.0.1') ||
    configuredEndpoint.includes('localhost')
  )) {
    result.aiServer.status = 'error';
    result.aiServer.endpoint = configuredEndpoint;
    result.aiServer.error = `Netlify Cloud cannot reach private LAN IP (${configuredEndpoint}). Netlify runs in the cloud and cannot access your local home/office network directly. Launch Cloudflare Tunnel on your Linux server ('cloudflared tunnel --url http://127.0.0.1:11434') and paste the public https://<subdomain>.trycloudflare.com URL here.`;
    return NextResponse.json(result);
  }

  // Build configured variants (pair port 11434 and 11435 automatically)
  const configuredVariants: string[] = [];
  if (configuredEndpoint) {
    configuredVariants.push(configuredEndpoint);
    if (configuredEndpoint.includes(':11435')) {
      configuredVariants.push(configuredEndpoint.replace(':11435', ':11434'));
    } else if (configuredEndpoint.includes(':11434')) {
      configuredVariants.push(configuredEndpoint.replace(':11434', ':11435'));
    }
  }

  const candidateEndpoints = (isCloudEnv
    ? [
        ...configuredVariants,
        'https://publicly-suggest-percent-relevant.trycloudflare.com/api/generate'
      ].filter(Boolean)
    : [
        'http://127.0.0.1:11434/api/generate',
        'http://192.168.0.80:11434/api/generate',
        'http://127.0.0.1:11435/api/generate',
        'http://192.168.0.80:11435/api/generate',
        ...configuredVariants
      ].filter(Boolean)
  ).filter(ep => 
    !ep.includes('entrepreneurs-psp-navigate-maternity') && 
    !ep.includes('your-tunnel-subdomain') && 
    !ep.includes('millions-librarian-consumer-desktops') &&
    !ep.includes('developers.cloudflare.com')
  ).filter((v, i, a) => a.indexOf(v) === i);

  if (candidateEndpoints.length === 0) {
    result.aiServer.status = 'unconfigured';
    result.aiServer.error = 'No AI tunnel URL configured yet. Enter your Cloudflare URL in Settings to connect.';
    return NextResponse.json(result);
  }

  result.aiServer.endpoint = candidateEndpoints[0];

  // 2. Multi-Probe candidate AI endpoints with resilient fallback
  let lastError = '';
  let connected = false;

  for (const ep of candidateEndpoints) {
    try {
      const baseUrl = ep
        .replace(/\/api\/generate\/?$/, '')
        .replace(/\/api\/chat\/?$/, '')
        .replace(/\/api\/?$/, '')
        .replace(/\/+$/, '');
      const authHeaders: Record<string, string> = {};
      if (configuredApiKey) {
        authHeaders['Authorization'] = `Bearer ${configuredApiKey}`;
        authHeaders['x-api-key'] = configuredApiKey;
      }

      let isUp = false;
      let modelList: string[] = [];
      const probeTimeout = 4000;

      // Probe 1: Direct Ollama /api/tags (with auth headers)
      try {
        const tagsRes = await fetch(`${baseUrl}/api/tags`, {
          method: 'GET',
          headers: authHeaders,
          signal: AbortSignal.timeout(probeTimeout)
        });
        if (tagsRes.ok) {
          const contentType = tagsRes.headers.get('content-type') || '';
          if (!contentType.includes('text/html')) {
            const data = await tagsRes.json();
            if (data && Array.isArray(data.models)) {
              modelList = data.models.map((m: any) => m.name) || [];
              isUp = true;
            }
          }
        }
      } catch (e: any) {
        lastError = e?.message || String(e);
      }

      // If connection was refused or fetch failed (port is dead), skip remaining slow probes on this port
      const isDeadPort = lastError && (
        lastError.toLowerCase().includes('fetch failed') ||
        lastError.toLowerCase().includes('econnrefused') ||
        lastError.toLowerCase().includes('enotfound')
      );

      // Probe 2: Ollama /api/tags (without auth headers, in case direct tunnel to 11434)
      if (!isUp && !isDeadPort) {
        try {
          const noAuthRes = await fetch(`${baseUrl}/api/tags`, {
            method: 'GET',
            signal: AbortSignal.timeout(probeTimeout)
          });
          if (noAuthRes.ok) {
            const contentType = noAuthRes.headers.get('content-type') || '';
            if (!contentType.includes('text/html')) {
              const data = await noAuthRes.json();
              if (data && Array.isArray(data.models)) {
                modelList = data.models.map((m: any) => m.name) || [];
                isUp = true;
              }
            }
          }
        } catch (e: any) {}
      }

      // Probe 3: Lightweight gateway ping (/ping or /healthz)
      if (!isUp && !isDeadPort) {
        try {
          const pingRes = await fetch(`${baseUrl}/ping`, {
            method: 'GET',
            headers: authHeaders,
            signal: AbortSignal.timeout(2500)
          });
          if (pingRes.ok) {
            const contentType = pingRes.headers.get('content-type') || '';
            if (!contentType.includes('text/html')) {
              const pingData = await pingRes.json();
              if (pingData && (pingData.gateway || pingData.status === 'ok')) {
                isUp = true;
              }
            }
          }
        } catch (e) {}
      }

      // Probe 4: Root endpoint (standard Ollama returns plain text "Ollama is running" with 200 OK)
      if (!isUp && !isDeadPort) {
        try {
          const rootRes = await fetch(`${baseUrl}/`, {
            method: 'GET',
            signal: AbortSignal.timeout(2500)
          });
          if (rootRes.ok) {
            const rootText = await rootRes.text();
            if (rootText.toLowerCase().includes('ollama is running')) {
              isUp = true;
            }
          }
        } catch (e) {}
      }

      // Probe 5: Ollama version check (/api/version returns JSON {"version":"..."})
      if (!isUp && !isDeadPort) {
        try {
          const verRes = await fetch(`${baseUrl}/api/version`, {
            method: 'GET',
            signal: AbortSignal.timeout(probeTimeout)
          });
          if (verRes.ok) {
            const contentType = verRes.headers.get('content-type') || '';
            if (!contentType.includes('text/html')) {
              const verData = await verRes.json();
              if (verData && verData.version) {
                isUp = true;
              }
            }
          }
        } catch (e) {}
      }

      if (isUp) {
        result.aiServer.status = 'connected';
        result.aiServer.endpoint = ep;
        result.aiServer.models = modelList.length > 0 ? modelList : ['llama3.1:latest'];
        result.aiServer.model = modelList.find((m: string) => m.includes('llama3.1')) || modelList[0] || 'llama3.1:latest';
        connected = true;
        break;
      } else if (!lastError) {
        lastError = `Target endpoint ${ep} is not an active Ollama AI instance.`;
      }
    } catch (e: any) {
      lastError = `${ep}: ${e?.message || String(e)}`;
    }
  }

  if (!connected) {
    result.aiServer.status = 'unreachable';
    result.aiServer.error = lastError;
  }

  return NextResponse.json(result);
}
