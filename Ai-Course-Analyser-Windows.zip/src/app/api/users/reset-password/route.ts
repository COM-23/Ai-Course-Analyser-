export const dynamic = "force-dynamic";
import { NextResponse } from 'next/server';
import { getDb } from "@/lib/db";
import { isCloudDbEnabled, cloudResetUserPassword } from "@/lib/cloud-db";
import bcrypt from 'bcryptjs';

export async function POST(req: Request) {
  try {
    const { id, newPassword } = await req.json();

    if (!id || !newPassword) {
      return NextResponse.json({ error: 'User ID and new password required' }, { status: 400 });
    }

    // Check strong password policy
    const settingsStmt = getDb().prepare('SELECT value FROM settings WHERE id = ?');
    const enforceStrongPwdRow = settingsStmt.get('enforceStrongPasswords') as any;
    const enforceStrongPwd = enforceStrongPwdRow ? JSON.parse(enforceStrongPwdRow.value) : false;
    
    if (enforceStrongPwd) {
      const strongRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{12,}$/;
      if (!strongRegex.test(newPassword)) {
        return NextResponse.json({ 
          error: 'Password must be at least 12 characters and include numbers, symbols, and mixed case letters.' 
        }, { status: 400 });
      }
    }

    const passwordHash = await bcrypt.hash(newPassword, 10);
    
    if (isCloudDbEnabled()) {
      try {
        await cloudResetUserPassword(Number(id), passwordHash);
        return NextResponse.json({ success: true });
      } catch (e) {}
    }

    const stmt = getDb().prepare('UPDATE users SET passwordHash = ? WHERE id = ?');
    stmt.run(passwordHash, id);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Password reset error:', error);
    return NextResponse.json({ error: 'Failed to reset password' }, { status: 500 });
  }
}
